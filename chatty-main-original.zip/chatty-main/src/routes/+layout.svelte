<script>
	import '../app.css'
</script>

<div class="flex flex-col items-center max-w-2xl mx-auto">
	<slot />
</div>
